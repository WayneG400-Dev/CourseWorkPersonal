const dba = require('idb-connector')
const mysql = require('mysql')

const db2Insert = (parseObject) => {
  return new Promise((resolve, reject) => {
    let keyString = ' '
    let sqlinserts = []
    for (var k in parseObject) keyString += ' , ' + k
    for (var property1 in parseObject) sqlinserts.push(parseObject[property1])
    const keyString1 = keyString.slice(3)
    const prepsql = `INSERT INTO WG_CORE.CODE(${keyString1}) values (?)`
    const sql = mysql.format(prepsql, sqlinserts)
    let dbconn = new dba.dbconn()
    dbconn.conn('*LOCAL')
    let sqlA = new dba.dbstmt(dbconn)
    sqlA.exec(sql, function (res, err) {
      sqlA.close()
      dbconn.disconn()
      dbconn.close()
      if (err) reject(new Error(err))
      resolve(res)
    })
  })
}

module.exports.db2Insert = db2Insert
