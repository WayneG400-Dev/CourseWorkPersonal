const db2 = require('./db2Insert')

const db2MultiInsert = (dataObjs) => {
  return new Promise((resolve, reject) => {
    const itemPromises = dataObjs.forEach(pgm => pgm.forEach(db2.db2Insert))
    Promise.all(itemPromises)
      .then((contents) => {
        resolve(contents)
        setTimeout(() => {
          // console.log('Kill it DEAD')
        }, 52000)
      }).catch((errorMessage) => {
        reject(new Error(errorMessage))
      })
  })
}

module.exports.db2MultiInsert = db2MultiInsert
