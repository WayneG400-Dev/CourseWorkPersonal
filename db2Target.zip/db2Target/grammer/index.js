const parse = require('./parse')

let multiParse = (fileObjects) => {
  return new Promise((resolve, reject) => {
    let itemPromises = fileObjects.forEach(element => {
      (parse.parseFile(element))
    })
    Promise.all(itemPromises)
      .then((contents) => {
        resolve(contents)
      }).catch((errorMessage) => {
        reject(new Error(errorMessage))
      })
  })
}

module.exports.multiParse = multiParse
