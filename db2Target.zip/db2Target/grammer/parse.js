/* Importing packages */
const antlr4 = require('antlr4/index')

/* Importing files */

/* Importing ANTLR GENERATED Javascript language specific files */
const Lexer = require('./rpgLexer')
const Parser = require('./rpgParser')
const ParserListenerOverride = require('./rpgParserListenerOverride')
const ErrorListenerOverride = require('./rpgErrorListenerOverride')

/* Forming Concatenated strings to call antlr parser for specific source language */
const lex = eval('Lexer.rpgLexer')
const par = eval('Parser.rpgParser')
const listOverride = eval('ParserListenerOverride.rpgParserListenerOverride')
const errListOverride = eval('ErrorListenerOverride.rpgErrorListenerOverride')

const parseFile = (fileObj) => {
  return new Promise((resolve, reject) => {
    var fName = fileObj.PGMName
    var data = fileObj.SrcCode
    var pgmName = `{"prgName":"${fName}",`
    if (data) {
      const chars = new antlr4.InputStream(data)
      const lexer = new lex(chars)
      const tokens = new antlr4.CommonTokenStream(lexer)
      const parser = new par(tokens)
      let errors = []
      parser.removeErrorListeners()
      let listener = new errListOverride(errors)
      parser.addErrorListener(listener)
      let tree = parser.startRule()
      let text = new listOverride()
      antlr4.tree.ParseTreeWalker.DEFAULT.walk(text, tree)
      parser.buildParseTrees = true
      const newData = ParserListenerOverride.jsonArray.map(data =>
        JSON.parse(pgmName + JSON.stringify(data).slice(1))
      )
      resolve(newData)
    } else {
      reject(new Error('File Object is Blank'))
    }
  })
}

module.exports.parseFile = parseFile
