const antlr4 = require('antlr4/index')
const rpgLexer = require('./rpgLexer')
const rpgParser = require('./rpgParser')

var rpgErrorListenerOverride = function (errors) {
  antlr4.error.ErrorListener.call(this) // inherit default listener
  this.errors = errors
  return this
}

// inherit default listener
rpgErrorListenerOverride.prototype = Object.create(antlr4.error.ErrorListener.prototype)
rpgErrorListenerOverride.prototype.constructor = rpgErrorListenerOverride

rpgErrorListenerOverride.prototype.syntaxError = function (recognizer, offendingSymbol, line, column, msg, e) {
  this.errors.push({
    row: line,
    column: column,
    text: msg,
    type: 'error'
  })
}

exports.rpgErrorListenerOverride = rpgErrorListenerOverride
