// Generated from rpgParser.g4 by ANTLR 4.7
// jshint ignore: start
var antlr4 = require('antlr4/index');

// This class defines a complete listener for a parse tree produced by rpgParser.
function rpgParserListener() {
	antlr4.tree.ParseTreeListener.call(this);
	return this;
}

rpgParserListener.prototype = Object.create(antlr4.tree.ParseTreeListener.prototype);
rpgParserListener.prototype.constructor = rpgParserListener;

// Enter a parse tree produced by rpgParser#startRule.
rpgParserListener.prototype.enterStartRule = function(ctx) {
};

// Exit a parse tree produced by rpgParser#startRule.
rpgParserListener.prototype.exitStartRule = function(ctx) {
};


// Enter a parse tree produced by rpgParser#statement.
rpgParserListener.prototype.enterStatement = function(ctx) {
};

// Exit a parse tree produced by rpgParser#statement.
rpgParserListener.prototype.exitStatement = function(ctx) {
};


// Enter a parse tree produced by rpgParser#fixed_statement.
rpgParserListener.prototype.enterFixed_statement = function(ctx) {
};

// Exit a parse tree produced by rpgParser#fixed_statement.
rpgParserListener.prototype.exitFixed_statement = function(ctx) {
};


// Enter a parse tree produced by rpgParser#comment_fixed.
rpgParserListener.prototype.enterComment_fixed = function(ctx) {
};

// Exit a parse tree produced by rpgParser#comment_fixed.
rpgParserListener.prototype.exitComment_fixed = function(ctx) {
};


// Enter a parse tree produced by rpgParser#fspec_fixed.
rpgParserListener.prototype.enterFspec_fixed = function(ctx) {
};

// Exit a parse tree produced by rpgParser#fspec_fixed.
rpgParserListener.prototype.exitFspec_fixed = function(ctx) {
};


// Enter a parse tree produced by rpgParser#hspec_fixed.
rpgParserListener.prototype.enterHspec_fixed = function(ctx) {
};

// Exit a parse tree produced by rpgParser#hspec_fixed.
rpgParserListener.prototype.exitHspec_fixed = function(ctx) {
};


// Enter a parse tree produced by rpgParser#dspec_fixed.
rpgParserListener.prototype.enterDspec_fixed = function(ctx) {
};

// Exit a parse tree produced by rpgParser#dspec_fixed.
rpgParserListener.prototype.exitDspec_fixed = function(ctx) {
};


// Enter a parse tree produced by rpgParser#cspec_fixed.
rpgParserListener.prototype.enterCspec_fixed = function(ctx) {
};

// Exit a parse tree produced by rpgParser#cspec_fixed.
rpgParserListener.prototype.exitCspec_fixed = function(ctx) {
};


// Enter a parse tree produced by rpgParser#cspec_fixed_continuation.
rpgParserListener.prototype.enterCspec_fixed_continuation = function(ctx) {
};

// Exit a parse tree produced by rpgParser#cspec_fixed_continuation.
rpgParserListener.prototype.exitCspec_fixed_continuation = function(ctx) {
};


// Enter a parse tree produced by rpgParser#pspec_fixed.
rpgParserListener.prototype.enterPspec_fixed = function(ctx) {
};

// Exit a parse tree produced by rpgParser#pspec_fixed.
rpgParserListener.prototype.exitPspec_fixed = function(ctx) {
};


// Enter a parse tree produced by rpgParser#cspec_fixed_sql.
rpgParserListener.prototype.enterCspec_fixed_sql = function(ctx) {
};

// Exit a parse tree produced by rpgParser#cspec_fixed_sql.
rpgParserListener.prototype.exitCspec_fixed_sql = function(ctx) {
};


// Enter a parse tree produced by rpgParser#cspec_fixed_sql_contd.
rpgParserListener.prototype.enterCspec_fixed_sql_contd = function(ctx) {
};

// Exit a parse tree produced by rpgParser#cspec_fixed_sql_contd.
rpgParserListener.prototype.exitCspec_fixed_sql_contd = function(ctx) {
};


// Enter a parse tree produced by rpgParser#cspec_fixed_sql_end.
rpgParserListener.prototype.enterCspec_fixed_sql_end = function(ctx) {
};

// Exit a parse tree produced by rpgParser#cspec_fixed_sql_end.
rpgParserListener.prototype.exitCspec_fixed_sql_end = function(ctx) {
};


// Enter a parse tree produced by rpgParser#free.
rpgParserListener.prototype.enterFree = function(ctx) {
};

// Exit a parse tree produced by rpgParser#free.
rpgParserListener.prototype.exitFree = function(ctx) {
};


// Enter a parse tree produced by rpgParser#fspec.
rpgParserListener.prototype.enterFspec = function(ctx) {
};

// Exit a parse tree produced by rpgParser#fspec.
rpgParserListener.prototype.exitFspec = function(ctx) {
};


// Enter a parse tree produced by rpgParser#filename.
rpgParserListener.prototype.enterFilename = function(ctx) {
};

// Exit a parse tree produced by rpgParser#filename.
rpgParserListener.prototype.exitFilename = function(ctx) {
};


// Enter a parse tree produced by rpgParser#fs_keyword.
rpgParserListener.prototype.enterFs_keyword = function(ctx) {
};

// Exit a parse tree produced by rpgParser#fs_keyword.
rpgParserListener.prototype.exitFs_keyword = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_block.
rpgParserListener.prototype.enterKeyword_block = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_block.
rpgParserListener.prototype.exitKeyword_block = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_commit.
rpgParserListener.prototype.enterKeyword_commit = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_commit.
rpgParserListener.prototype.exitKeyword_commit = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_devid.
rpgParserListener.prototype.enterKeyword_devid = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_devid.
rpgParserListener.prototype.exitKeyword_devid = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_extdesc.
rpgParserListener.prototype.enterKeyword_extdesc = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_extdesc.
rpgParserListener.prototype.exitKeyword_extdesc = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_extfile.
rpgParserListener.prototype.enterKeyword_extfile = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_extfile.
rpgParserListener.prototype.exitKeyword_extfile = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_extind.
rpgParserListener.prototype.enterKeyword_extind = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_extind.
rpgParserListener.prototype.exitKeyword_extind = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_extmbr.
rpgParserListener.prototype.enterKeyword_extmbr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_extmbr.
rpgParserListener.prototype.exitKeyword_extmbr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_formlen.
rpgParserListener.prototype.enterKeyword_formlen = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_formlen.
rpgParserListener.prototype.exitKeyword_formlen = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_formofl.
rpgParserListener.prototype.enterKeyword_formofl = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_formofl.
rpgParserListener.prototype.exitKeyword_formofl = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_ignore.
rpgParserListener.prototype.enterKeyword_ignore = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_ignore.
rpgParserListener.prototype.exitKeyword_ignore = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_include.
rpgParserListener.prototype.enterKeyword_include = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_include.
rpgParserListener.prototype.exitKeyword_include = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_indds.
rpgParserListener.prototype.enterKeyword_indds = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_indds.
rpgParserListener.prototype.exitKeyword_indds = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_infds.
rpgParserListener.prototype.enterKeyword_infds = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_infds.
rpgParserListener.prototype.exitKeyword_infds = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_infsr.
rpgParserListener.prototype.enterKeyword_infsr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_infsr.
rpgParserListener.prototype.exitKeyword_infsr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_keyloc.
rpgParserListener.prototype.enterKeyword_keyloc = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_keyloc.
rpgParserListener.prototype.exitKeyword_keyloc = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_maxdev.
rpgParserListener.prototype.enterKeyword_maxdev = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_maxdev.
rpgParserListener.prototype.exitKeyword_maxdev = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_oflind.
rpgParserListener.prototype.enterKeyword_oflind = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_oflind.
rpgParserListener.prototype.exitKeyword_oflind = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_pass.
rpgParserListener.prototype.enterKeyword_pass = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_pass.
rpgParserListener.prototype.exitKeyword_pass = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_pgmname.
rpgParserListener.prototype.enterKeyword_pgmname = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_pgmname.
rpgParserListener.prototype.exitKeyword_pgmname = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_plist.
rpgParserListener.prototype.enterKeyword_plist = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_plist.
rpgParserListener.prototype.exitKeyword_plist = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_prtctl.
rpgParserListener.prototype.enterKeyword_prtctl = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_prtctl.
rpgParserListener.prototype.exitKeyword_prtctl = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_rafdata.
rpgParserListener.prototype.enterKeyword_rafdata = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_rafdata.
rpgParserListener.prototype.exitKeyword_rafdata = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_recno.
rpgParserListener.prototype.enterKeyword_recno = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_recno.
rpgParserListener.prototype.exitKeyword_recno = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_rename.
rpgParserListener.prototype.enterKeyword_rename = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_rename.
rpgParserListener.prototype.exitKeyword_rename = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_saveds.
rpgParserListener.prototype.enterKeyword_saveds = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_saveds.
rpgParserListener.prototype.exitKeyword_saveds = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_saveind.
rpgParserListener.prototype.enterKeyword_saveind = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_saveind.
rpgParserListener.prototype.exitKeyword_saveind = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_sfile.
rpgParserListener.prototype.enterKeyword_sfile = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_sfile.
rpgParserListener.prototype.exitKeyword_sfile = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_sln.
rpgParserListener.prototype.enterKeyword_sln = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_sln.
rpgParserListener.prototype.exitKeyword_sln = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_usropn.
rpgParserListener.prototype.enterKeyword_usropn = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_usropn.
rpgParserListener.prototype.exitKeyword_usropn = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_disk.
rpgParserListener.prototype.enterKeyword_disk = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_disk.
rpgParserListener.prototype.exitKeyword_disk = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_workstn.
rpgParserListener.prototype.enterKeyword_workstn = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_workstn.
rpgParserListener.prototype.exitKeyword_workstn = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_printer.
rpgParserListener.prototype.enterKeyword_printer = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_printer.
rpgParserListener.prototype.exitKeyword_printer = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_special.
rpgParserListener.prototype.enterKeyword_special = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_special.
rpgParserListener.prototype.exitKeyword_special = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_keyed.
rpgParserListener.prototype.enterKeyword_keyed = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_keyed.
rpgParserListener.prototype.exitKeyword_keyed = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_usage.
rpgParserListener.prototype.enterKeyword_usage = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_usage.
rpgParserListener.prototype.exitKeyword_usage = function(ctx) {
};


// Enter a parse tree produced by rpgParser#dcl_ds.
rpgParserListener.prototype.enterDcl_ds = function(ctx) {
};

// Exit a parse tree produced by rpgParser#dcl_ds.
rpgParserListener.prototype.exitDcl_ds = function(ctx) {
};


// Enter a parse tree produced by rpgParser#dspec.
rpgParserListener.prototype.enterDspec = function(ctx) {
};

// Exit a parse tree produced by rpgParser#dspec.
rpgParserListener.prototype.exitDspec = function(ctx) {
};


// Enter a parse tree produced by rpgParser#datatype.
rpgParserListener.prototype.enterDatatype = function(ctx) {
};

// Exit a parse tree produced by rpgParser#datatype.
rpgParserListener.prototype.exitDatatype = function(ctx) {
};


// Enter a parse tree produced by rpgParser#datatypeName.
rpgParserListener.prototype.enterDatatypeName = function(ctx) {
};

// Exit a parse tree produced by rpgParser#datatypeName.
rpgParserListener.prototype.exitDatatypeName = function(ctx) {
};


// Enter a parse tree produced by rpgParser#dcl_pi.
rpgParserListener.prototype.enterDcl_pi = function(ctx) {
};

// Exit a parse tree produced by rpgParser#dcl_pi.
rpgParserListener.prototype.exitDcl_pi = function(ctx) {
};


// Enter a parse tree produced by rpgParser#dcl_field.
rpgParserListener.prototype.enterDcl_field = function(ctx) {
};

// Exit a parse tree produced by rpgParser#dcl_field.
rpgParserListener.prototype.exitDcl_field = function(ctx) {
};


// Enter a parse tree produced by rpgParser#end_dcl_pi.
rpgParserListener.prototype.enterEnd_dcl_pi = function(ctx) {
};

// Exit a parse tree produced by rpgParser#end_dcl_pi.
rpgParserListener.prototype.exitEnd_dcl_pi = function(ctx) {
};


// Enter a parse tree produced by rpgParser#dcl_pr.
rpgParserListener.prototype.enterDcl_pr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#dcl_pr.
rpgParserListener.prototype.exitDcl_pr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#end_dcl_pr.
rpgParserListener.prototype.enterEnd_dcl_pr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#end_dcl_pr.
rpgParserListener.prototype.exitEnd_dcl_pr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#ctl_opt.
rpgParserListener.prototype.enterCtl_opt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#ctl_opt.
rpgParserListener.prototype.exitCtl_opt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#onErrorCode.
rpgParserListener.prototype.enterOnErrorCode = function(ctx) {
};

// Exit a parse tree produced by rpgParser#onErrorCode.
rpgParserListener.prototype.exitOnErrorCode = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword.
rpgParserListener.prototype.enterKeyword = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword.
rpgParserListener.prototype.exitKeyword = function(ctx) {
};


// Enter a parse tree produced by rpgParser#dspec_bif.
rpgParserListener.prototype.enterDspec_bif = function(ctx) {
};

// Exit a parse tree produced by rpgParser#dspec_bif.
rpgParserListener.prototype.exitDspec_bif = function(ctx) {
};


// Enter a parse tree produced by rpgParser#dateSeparator.
rpgParserListener.prototype.enterDateSeparator = function(ctx) {
};

// Exit a parse tree produced by rpgParser#dateSeparator.
rpgParserListener.prototype.exitDateSeparator = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_actgrp.
rpgParserListener.prototype.enterKeyword_actgrp = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_actgrp.
rpgParserListener.prototype.exitKeyword_actgrp = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_alias.
rpgParserListener.prototype.enterKeyword_alias = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_alias.
rpgParserListener.prototype.exitKeyword_alias = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_align.
rpgParserListener.prototype.enterKeyword_align = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_align.
rpgParserListener.prototype.exitKeyword_align = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_alt.
rpgParserListener.prototype.enterKeyword_alt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_alt.
rpgParserListener.prototype.exitKeyword_alt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_altseq.
rpgParserListener.prototype.enterKeyword_altseq = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_altseq.
rpgParserListener.prototype.exitKeyword_altseq = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_ascend.
rpgParserListener.prototype.enterKeyword_ascend = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_ascend.
rpgParserListener.prototype.exitKeyword_ascend = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_based.
rpgParserListener.prototype.enterKeyword_based = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_based.
rpgParserListener.prototype.exitKeyword_based = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_ccsid.
rpgParserListener.prototype.enterKeyword_ccsid = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_ccsid.
rpgParserListener.prototype.exitKeyword_ccsid = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_class.
rpgParserListener.prototype.enterKeyword_class = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_class.
rpgParserListener.prototype.exitKeyword_class = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_const.
rpgParserListener.prototype.enterKeyword_const = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_const.
rpgParserListener.prototype.exitKeyword_const = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_ctdata.
rpgParserListener.prototype.enterKeyword_ctdata = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_ctdata.
rpgParserListener.prototype.exitKeyword_ctdata = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_datedit.
rpgParserListener.prototype.enterKeyword_datedit = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_datedit.
rpgParserListener.prototype.exitKeyword_datedit = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_datfmt.
rpgParserListener.prototype.enterKeyword_datfmt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_datfmt.
rpgParserListener.prototype.exitKeyword_datfmt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_debug.
rpgParserListener.prototype.enterKeyword_debug = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_debug.
rpgParserListener.prototype.exitKeyword_debug = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_descend.
rpgParserListener.prototype.enterKeyword_descend = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_descend.
rpgParserListener.prototype.exitKeyword_descend = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_dftactgrp.
rpgParserListener.prototype.enterKeyword_dftactgrp = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_dftactgrp.
rpgParserListener.prototype.exitKeyword_dftactgrp = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_dim.
rpgParserListener.prototype.enterKeyword_dim = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_dim.
rpgParserListener.prototype.exitKeyword_dim = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_dtaara.
rpgParserListener.prototype.enterKeyword_dtaara = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_dtaara.
rpgParserListener.prototype.exitKeyword_dtaara = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_export.
rpgParserListener.prototype.enterKeyword_export = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_export.
rpgParserListener.prototype.exitKeyword_export = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_serialize.
rpgParserListener.prototype.enterKeyword_serialize = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_serialize.
rpgParserListener.prototype.exitKeyword_serialize = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_ext.
rpgParserListener.prototype.enterKeyword_ext = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_ext.
rpgParserListener.prototype.exitKeyword_ext = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_extfld.
rpgParserListener.prototype.enterKeyword_extfld = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_extfld.
rpgParserListener.prototype.exitKeyword_extfld = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_extfmt.
rpgParserListener.prototype.enterKeyword_extfmt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_extfmt.
rpgParserListener.prototype.exitKeyword_extfmt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_extname.
rpgParserListener.prototype.enterKeyword_extname = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_extname.
rpgParserListener.prototype.exitKeyword_extname = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_extpgm.
rpgParserListener.prototype.enterKeyword_extpgm = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_extpgm.
rpgParserListener.prototype.exitKeyword_extpgm = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_extproc.
rpgParserListener.prototype.enterKeyword_extproc = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_extproc.
rpgParserListener.prototype.exitKeyword_extproc = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_fromfile.
rpgParserListener.prototype.enterKeyword_fromfile = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_fromfile.
rpgParserListener.prototype.exitKeyword_fromfile = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_import.
rpgParserListener.prototype.enterKeyword_import = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_import.
rpgParserListener.prototype.exitKeyword_import = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_inz.
rpgParserListener.prototype.enterKeyword_inz = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_inz.
rpgParserListener.prototype.exitKeyword_inz = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_len.
rpgParserListener.prototype.enterKeyword_len = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_len.
rpgParserListener.prototype.exitKeyword_len = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_like.
rpgParserListener.prototype.enterKeyword_like = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_like.
rpgParserListener.prototype.exitKeyword_like = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_likeds.
rpgParserListener.prototype.enterKeyword_likeds = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_likeds.
rpgParserListener.prototype.exitKeyword_likeds = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_likefile.
rpgParserListener.prototype.enterKeyword_likefile = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_likefile.
rpgParserListener.prototype.exitKeyword_likefile = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_likerec.
rpgParserListener.prototype.enterKeyword_likerec = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_likerec.
rpgParserListener.prototype.exitKeyword_likerec = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_noopt.
rpgParserListener.prototype.enterKeyword_noopt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_noopt.
rpgParserListener.prototype.exitKeyword_noopt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_occurs.
rpgParserListener.prototype.enterKeyword_occurs = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_occurs.
rpgParserListener.prototype.exitKeyword_occurs = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_opdesc.
rpgParserListener.prototype.enterKeyword_opdesc = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_opdesc.
rpgParserListener.prototype.exitKeyword_opdesc = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_option.
rpgParserListener.prototype.enterKeyword_option = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_option.
rpgParserListener.prototype.exitKeyword_option = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_options.
rpgParserListener.prototype.enterKeyword_options = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_options.
rpgParserListener.prototype.exitKeyword_options = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_overlay.
rpgParserListener.prototype.enterKeyword_overlay = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_overlay.
rpgParserListener.prototype.exitKeyword_overlay = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_packeven.
rpgParserListener.prototype.enterKeyword_packeven = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_packeven.
rpgParserListener.prototype.exitKeyword_packeven = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_perrcd.
rpgParserListener.prototype.enterKeyword_perrcd = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_perrcd.
rpgParserListener.prototype.exitKeyword_perrcd = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_prefix.
rpgParserListener.prototype.enterKeyword_prefix = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_prefix.
rpgParserListener.prototype.exitKeyword_prefix = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_pos.
rpgParserListener.prototype.enterKeyword_pos = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_pos.
rpgParserListener.prototype.exitKeyword_pos = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_procptr.
rpgParserListener.prototype.enterKeyword_procptr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_procptr.
rpgParserListener.prototype.exitKeyword_procptr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_qualified.
rpgParserListener.prototype.enterKeyword_qualified = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_qualified.
rpgParserListener.prototype.exitKeyword_qualified = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_rtnparm.
rpgParserListener.prototype.enterKeyword_rtnparm = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_rtnparm.
rpgParserListener.prototype.exitKeyword_rtnparm = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_static.
rpgParserListener.prototype.enterKeyword_static = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_static.
rpgParserListener.prototype.exitKeyword_static = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_sqltype.
rpgParserListener.prototype.enterKeyword_sqltype = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_sqltype.
rpgParserListener.prototype.exitKeyword_sqltype = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_template.
rpgParserListener.prototype.enterKeyword_template = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_template.
rpgParserListener.prototype.exitKeyword_template = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_timfmt.
rpgParserListener.prototype.enterKeyword_timfmt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_timfmt.
rpgParserListener.prototype.exitKeyword_timfmt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_tofile.
rpgParserListener.prototype.enterKeyword_tofile = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_tofile.
rpgParserListener.prototype.exitKeyword_tofile = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_value.
rpgParserListener.prototype.enterKeyword_value = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_value.
rpgParserListener.prototype.exitKeyword_value = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_varying.
rpgParserListener.prototype.enterKeyword_varying = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_varying.
rpgParserListener.prototype.exitKeyword_varying = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_psds.
rpgParserListener.prototype.enterKeyword_psds = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_psds.
rpgParserListener.prototype.exitKeyword_psds = function(ctx) {
};


// Enter a parse tree produced by rpgParser#keyword_alloc.
rpgParserListener.prototype.enterKeyword_alloc = function(ctx) {
};

// Exit a parse tree produced by rpgParser#keyword_alloc.
rpgParserListener.prototype.exitKeyword_alloc = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op.
rpgParserListener.prototype.enterOp = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op.
rpgParserListener.prototype.exitOp = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_acq.
rpgParserListener.prototype.enterOp_acq = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_acq.
rpgParserListener.prototype.exitOp_acq = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_begsr.
rpgParserListener.prototype.enterOp_begsr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_begsr.
rpgParserListener.prototype.exitOp_begsr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_callp.
rpgParserListener.prototype.enterOp_callp = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_callp.
rpgParserListener.prototype.exitOp_callp = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_chain.
rpgParserListener.prototype.enterOp_chain = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_chain.
rpgParserListener.prototype.exitOp_chain = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_clear.
rpgParserListener.prototype.enterOp_clear = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_clear.
rpgParserListener.prototype.exitOp_clear = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_close.
rpgParserListener.prototype.enterOp_close = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_close.
rpgParserListener.prototype.exitOp_close = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_commit.
rpgParserListener.prototype.enterOp_commit = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_commit.
rpgParserListener.prototype.exitOp_commit = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_dealloc.
rpgParserListener.prototype.enterOp_dealloc = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_dealloc.
rpgParserListener.prototype.exitOp_dealloc = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_delete.
rpgParserListener.prototype.enterOp_delete = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_delete.
rpgParserListener.prototype.exitOp_delete = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_dou.
rpgParserListener.prototype.enterOp_dou = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_dou.
rpgParserListener.prototype.exitOp_dou = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_dow.
rpgParserListener.prototype.enterOp_dow = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_dow.
rpgParserListener.prototype.exitOp_dow = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_dsply.
rpgParserListener.prototype.enterOp_dsply = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_dsply.
rpgParserListener.prototype.exitOp_dsply = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_dump.
rpgParserListener.prototype.enterOp_dump = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_dump.
rpgParserListener.prototype.exitOp_dump = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_else.
rpgParserListener.prototype.enterOp_else = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_else.
rpgParserListener.prototype.exitOp_else = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_elseif.
rpgParserListener.prototype.enterOp_elseif = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_elseif.
rpgParserListener.prototype.exitOp_elseif = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_enddo.
rpgParserListener.prototype.enterOp_enddo = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_enddo.
rpgParserListener.prototype.exitOp_enddo = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_endfor.
rpgParserListener.prototype.enterOp_endfor = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_endfor.
rpgParserListener.prototype.exitOp_endfor = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_endif.
rpgParserListener.prototype.enterOp_endif = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_endif.
rpgParserListener.prototype.exitOp_endif = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_endmon.
rpgParserListener.prototype.enterOp_endmon = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_endmon.
rpgParserListener.prototype.exitOp_endmon = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_endsl.
rpgParserListener.prototype.enterOp_endsl = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_endsl.
rpgParserListener.prototype.exitOp_endsl = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_endsr.
rpgParserListener.prototype.enterOp_endsr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_endsr.
rpgParserListener.prototype.exitOp_endsr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_eval.
rpgParserListener.prototype.enterOp_eval = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_eval.
rpgParserListener.prototype.exitOp_eval = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_evalr.
rpgParserListener.prototype.enterOp_evalr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_evalr.
rpgParserListener.prototype.exitOp_evalr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_eval_corr.
rpgParserListener.prototype.enterOp_eval_corr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_eval_corr.
rpgParserListener.prototype.exitOp_eval_corr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_except.
rpgParserListener.prototype.enterOp_except = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_except.
rpgParserListener.prototype.exitOp_except = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_exfmt.
rpgParserListener.prototype.enterOp_exfmt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_exfmt.
rpgParserListener.prototype.exitOp_exfmt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_exsr.
rpgParserListener.prototype.enterOp_exsr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_exsr.
rpgParserListener.prototype.exitOp_exsr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_feod.
rpgParserListener.prototype.enterOp_feod = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_feod.
rpgParserListener.prototype.exitOp_feod = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_for.
rpgParserListener.prototype.enterOp_for = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_for.
rpgParserListener.prototype.exitOp_for = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_force.
rpgParserListener.prototype.enterOp_force = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_force.
rpgParserListener.prototype.exitOp_force = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_if.
rpgParserListener.prototype.enterOp_if = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_if.
rpgParserListener.prototype.exitOp_if = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_in.
rpgParserListener.prototype.enterOp_in = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_in.
rpgParserListener.prototype.exitOp_in = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_iter.
rpgParserListener.prototype.enterOp_iter = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_iter.
rpgParserListener.prototype.exitOp_iter = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_leave.
rpgParserListener.prototype.enterOp_leave = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_leave.
rpgParserListener.prototype.exitOp_leave = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_leavesr.
rpgParserListener.prototype.enterOp_leavesr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_leavesr.
rpgParserListener.prototype.exitOp_leavesr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_monitor.
rpgParserListener.prototype.enterOp_monitor = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_monitor.
rpgParserListener.prototype.exitOp_monitor = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_next.
rpgParserListener.prototype.enterOp_next = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_next.
rpgParserListener.prototype.exitOp_next = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_on_error.
rpgParserListener.prototype.enterOp_on_error = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_on_error.
rpgParserListener.prototype.exitOp_on_error = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_open.
rpgParserListener.prototype.enterOp_open = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_open.
rpgParserListener.prototype.exitOp_open = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_other.
rpgParserListener.prototype.enterOp_other = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_other.
rpgParserListener.prototype.exitOp_other = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_out.
rpgParserListener.prototype.enterOp_out = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_out.
rpgParserListener.prototype.exitOp_out = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_post.
rpgParserListener.prototype.enterOp_post = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_post.
rpgParserListener.prototype.exitOp_post = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_read.
rpgParserListener.prototype.enterOp_read = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_read.
rpgParserListener.prototype.exitOp_read = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_readc.
rpgParserListener.prototype.enterOp_readc = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_readc.
rpgParserListener.prototype.exitOp_readc = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_reade.
rpgParserListener.prototype.enterOp_reade = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_reade.
rpgParserListener.prototype.exitOp_reade = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_readp.
rpgParserListener.prototype.enterOp_readp = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_readp.
rpgParserListener.prototype.exitOp_readp = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_readpe.
rpgParserListener.prototype.enterOp_readpe = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_readpe.
rpgParserListener.prototype.exitOp_readpe = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_rel.
rpgParserListener.prototype.enterOp_rel = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_rel.
rpgParserListener.prototype.exitOp_rel = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_reset2.
rpgParserListener.prototype.enterOp_reset2 = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_reset2.
rpgParserListener.prototype.exitOp_reset2 = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_reset.
rpgParserListener.prototype.enterOp_reset = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_reset.
rpgParserListener.prototype.exitOp_reset = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_return.
rpgParserListener.prototype.enterOp_return = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_return.
rpgParserListener.prototype.exitOp_return = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_rolbk.
rpgParserListener.prototype.enterOp_rolbk = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_rolbk.
rpgParserListener.prototype.exitOp_rolbk = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_select.
rpgParserListener.prototype.enterOp_select = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_select.
rpgParserListener.prototype.exitOp_select = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_setgt.
rpgParserListener.prototype.enterOp_setgt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_setgt.
rpgParserListener.prototype.exitOp_setgt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_setll.
rpgParserListener.prototype.enterOp_setll = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_setll.
rpgParserListener.prototype.exitOp_setll = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_sorta.
rpgParserListener.prototype.enterOp_sorta = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_sorta.
rpgParserListener.prototype.exitOp_sorta = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_test.
rpgParserListener.prototype.enterOp_test = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_test.
rpgParserListener.prototype.exitOp_test = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_unlock.
rpgParserListener.prototype.enterOp_unlock = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_unlock.
rpgParserListener.prototype.exitOp_unlock = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_update.
rpgParserListener.prototype.enterOp_update = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_update.
rpgParserListener.prototype.exitOp_update = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_when.
rpgParserListener.prototype.enterOp_when = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_when.
rpgParserListener.prototype.exitOp_when = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_write.
rpgParserListener.prototype.enterOp_write = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_write.
rpgParserListener.prototype.exitOp_write = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_xml_into.
rpgParserListener.prototype.enterOp_xml_into = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_xml_into.
rpgParserListener.prototype.exitOp_xml_into = function(ctx) {
};


// Enter a parse tree produced by rpgParser#op_xml_sax.
rpgParserListener.prototype.enterOp_xml_sax = function(ctx) {
};

// Exit a parse tree produced by rpgParser#op_xml_sax.
rpgParserListener.prototype.exitOp_xml_sax = function(ctx) {
};


// Enter a parse tree produced by rpgParser#expr.
rpgParserListener.prototype.enterExpr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#expr.
rpgParserListener.prototype.exitExpr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#procedure.
rpgParserListener.prototype.enterProcedure = function(ctx) {
};

// Exit a parse tree produced by rpgParser#procedure.
rpgParserListener.prototype.exitProcedure = function(ctx) {
};


// Enter a parse tree produced by rpgParser#params.
rpgParserListener.prototype.enterParams = function(ctx) {
};

// Exit a parse tree produced by rpgParser#params.
rpgParserListener.prototype.exitParams = function(ctx) {
};


// Enter a parse tree produced by rpgParser#args.
rpgParserListener.prototype.enterArgs = function(ctx) {
};

// Exit a parse tree produced by rpgParser#args.
rpgParserListener.prototype.exitArgs = function(ctx) {
};


// Enter a parse tree produced by rpgParser#search_arg.
rpgParserListener.prototype.enterSearch_arg = function(ctx) {
};

// Exit a parse tree produced by rpgParser#search_arg.
rpgParserListener.prototype.exitSearch_arg = function(ctx) {
};


// Enter a parse tree produced by rpgParser#literal.
rpgParserListener.prototype.enterLiteral = function(ctx) {
};

// Exit a parse tree produced by rpgParser#literal.
rpgParserListener.prototype.exitLiteral = function(ctx) {
};


// Enter a parse tree produced by rpgParser#qualifier.
rpgParserListener.prototype.enterQualifier = function(ctx) {
};

// Exit a parse tree produced by rpgParser#qualifier.
rpgParserListener.prototype.exitQualifier = function(ctx) {
};


// Enter a parse tree produced by rpgParser#linecomments.
rpgParserListener.prototype.enterLinecomments = function(ctx) {
};

// Exit a parse tree produced by rpgParser#linecomments.
rpgParserListener.prototype.exitLinecomments = function(ctx) {
};


// Enter a parse tree produced by rpgParser#like_lengthAdjustment.
rpgParserListener.prototype.enterLike_lengthAdjustment = function(ctx) {
};

// Exit a parse tree produced by rpgParser#like_lengthAdjustment.
rpgParserListener.prototype.exitLike_lengthAdjustment = function(ctx) {
};


// Enter a parse tree produced by rpgParser#sign.
rpgParserListener.prototype.enterSign = function(ctx) {
};

// Exit a parse tree produced by rpgParser#sign.
rpgParserListener.prototype.exitSign = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif.
rpgParserListener.prototype.enterBif = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif.
rpgParserListener.prototype.exitBif = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_abs.
rpgParserListener.prototype.enterBif_abs = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_abs.
rpgParserListener.prototype.exitBif_abs = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_addr.
rpgParserListener.prototype.enterBif_addr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_addr.
rpgParserListener.prototype.exitBif_addr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_alloc.
rpgParserListener.prototype.enterBif_alloc = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_alloc.
rpgParserListener.prototype.exitBif_alloc = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_bitand.
rpgParserListener.prototype.enterBif_bitand = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_bitand.
rpgParserListener.prototype.exitBif_bitand = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_bitnot.
rpgParserListener.prototype.enterBif_bitnot = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_bitnot.
rpgParserListener.prototype.exitBif_bitnot = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_bitor.
rpgParserListener.prototype.enterBif_bitor = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_bitor.
rpgParserListener.prototype.exitBif_bitor = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_bitxor.
rpgParserListener.prototype.enterBif_bitxor = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_bitxor.
rpgParserListener.prototype.exitBif_bitxor = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_char.
rpgParserListener.prototype.enterBif_char = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_char.
rpgParserListener.prototype.exitBif_char = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_check.
rpgParserListener.prototype.enterBif_check = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_check.
rpgParserListener.prototype.exitBif_check = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_checkr.
rpgParserListener.prototype.enterBif_checkr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_checkr.
rpgParserListener.prototype.exitBif_checkr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_date.
rpgParserListener.prototype.enterBif_date = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_date.
rpgParserListener.prototype.exitBif_date = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_days.
rpgParserListener.prototype.enterBif_days = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_days.
rpgParserListener.prototype.exitBif_days = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_dec.
rpgParserListener.prototype.enterBif_dec = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_dec.
rpgParserListener.prototype.exitBif_dec = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_dech.
rpgParserListener.prototype.enterBif_dech = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_dech.
rpgParserListener.prototype.exitBif_dech = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_decpos.
rpgParserListener.prototype.enterBif_decpos = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_decpos.
rpgParserListener.prototype.exitBif_decpos = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_diff.
rpgParserListener.prototype.enterBif_diff = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_diff.
rpgParserListener.prototype.exitBif_diff = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_div.
rpgParserListener.prototype.enterBif_div = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_div.
rpgParserListener.prototype.exitBif_div = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_editc.
rpgParserListener.prototype.enterBif_editc = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_editc.
rpgParserListener.prototype.exitBif_editc = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_editflt.
rpgParserListener.prototype.enterBif_editflt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_editflt.
rpgParserListener.prototype.exitBif_editflt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_editw.
rpgParserListener.prototype.enterBif_editw = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_editw.
rpgParserListener.prototype.exitBif_editw = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_elem.
rpgParserListener.prototype.enterBif_elem = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_elem.
rpgParserListener.prototype.exitBif_elem = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_eof.
rpgParserListener.prototype.enterBif_eof = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_eof.
rpgParserListener.prototype.exitBif_eof = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_equal.
rpgParserListener.prototype.enterBif_equal = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_equal.
rpgParserListener.prototype.exitBif_equal = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_error.
rpgParserListener.prototype.enterBif_error = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_error.
rpgParserListener.prototype.exitBif_error = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_fields.
rpgParserListener.prototype.enterBif_fields = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_fields.
rpgParserListener.prototype.exitBif_fields = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_float.
rpgParserListener.prototype.enterBif_float = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_float.
rpgParserListener.prototype.exitBif_float = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_found.
rpgParserListener.prototype.enterBif_found = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_found.
rpgParserListener.prototype.exitBif_found = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_graph.
rpgParserListener.prototype.enterBif_graph = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_graph.
rpgParserListener.prototype.exitBif_graph = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_handler.
rpgParserListener.prototype.enterBif_handler = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_handler.
rpgParserListener.prototype.exitBif_handler = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_hours.
rpgParserListener.prototype.enterBif_hours = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_hours.
rpgParserListener.prototype.exitBif_hours = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_int.
rpgParserListener.prototype.enterBif_int = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_int.
rpgParserListener.prototype.exitBif_int = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_inth.
rpgParserListener.prototype.enterBif_inth = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_inth.
rpgParserListener.prototype.exitBif_inth = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_kds.
rpgParserListener.prototype.enterBif_kds = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_kds.
rpgParserListener.prototype.exitBif_kds = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_len.
rpgParserListener.prototype.enterBif_len = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_len.
rpgParserListener.prototype.exitBif_len = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_lookup.
rpgParserListener.prototype.enterBif_lookup = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_lookup.
rpgParserListener.prototype.exitBif_lookup = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_lookuplt.
rpgParserListener.prototype.enterBif_lookuplt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_lookuplt.
rpgParserListener.prototype.exitBif_lookuplt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_lookuple.
rpgParserListener.prototype.enterBif_lookuple = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_lookuple.
rpgParserListener.prototype.exitBif_lookuple = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_lookupgt.
rpgParserListener.prototype.enterBif_lookupgt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_lookupgt.
rpgParserListener.prototype.exitBif_lookupgt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_lookupge.
rpgParserListener.prototype.enterBif_lookupge = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_lookupge.
rpgParserListener.prototype.exitBif_lookupge = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_minutes.
rpgParserListener.prototype.enterBif_minutes = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_minutes.
rpgParserListener.prototype.exitBif_minutes = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_months.
rpgParserListener.prototype.enterBif_months = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_months.
rpgParserListener.prototype.exitBif_months = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_mseconds.
rpgParserListener.prototype.enterBif_mseconds = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_mseconds.
rpgParserListener.prototype.exitBif_mseconds = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_nullind.
rpgParserListener.prototype.enterBif_nullind = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_nullind.
rpgParserListener.prototype.exitBif_nullind = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_occur.
rpgParserListener.prototype.enterBif_occur = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_occur.
rpgParserListener.prototype.exitBif_occur = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_open.
rpgParserListener.prototype.enterBif_open = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_open.
rpgParserListener.prototype.exitBif_open = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_paddr.
rpgParserListener.prototype.enterBif_paddr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_paddr.
rpgParserListener.prototype.exitBif_paddr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_parms.
rpgParserListener.prototype.enterBif_parms = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_parms.
rpgParserListener.prototype.exitBif_parms = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_parmnum.
rpgParserListener.prototype.enterBif_parmnum = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_parmnum.
rpgParserListener.prototype.exitBif_parmnum = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_realloc.
rpgParserListener.prototype.enterBif_realloc = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_realloc.
rpgParserListener.prototype.exitBif_realloc = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_rem.
rpgParserListener.prototype.enterBif_rem = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_rem.
rpgParserListener.prototype.exitBif_rem = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_replace.
rpgParserListener.prototype.enterBif_replace = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_replace.
rpgParserListener.prototype.exitBif_replace = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_scan.
rpgParserListener.prototype.enterBif_scan = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_scan.
rpgParserListener.prototype.exitBif_scan = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_scanrpl.
rpgParserListener.prototype.enterBif_scanrpl = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_scanrpl.
rpgParserListener.prototype.exitBif_scanrpl = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_seconds.
rpgParserListener.prototype.enterBif_seconds = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_seconds.
rpgParserListener.prototype.exitBif_seconds = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_shtdn.
rpgParserListener.prototype.enterBif_shtdn = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_shtdn.
rpgParserListener.prototype.exitBif_shtdn = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_size.
rpgParserListener.prototype.enterBif_size = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_size.
rpgParserListener.prototype.exitBif_size = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_sqrt.
rpgParserListener.prototype.enterBif_sqrt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_sqrt.
rpgParserListener.prototype.exitBif_sqrt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_status.
rpgParserListener.prototype.enterBif_status = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_status.
rpgParserListener.prototype.exitBif_status = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_str.
rpgParserListener.prototype.enterBif_str = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_str.
rpgParserListener.prototype.exitBif_str = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_subarr.
rpgParserListener.prototype.enterBif_subarr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_subarr.
rpgParserListener.prototype.exitBif_subarr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_subdt.
rpgParserListener.prototype.enterBif_subdt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_subdt.
rpgParserListener.prototype.exitBif_subdt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_subst.
rpgParserListener.prototype.enterBif_subst = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_subst.
rpgParserListener.prototype.exitBif_subst = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_this.
rpgParserListener.prototype.enterBif_this = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_this.
rpgParserListener.prototype.exitBif_this = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_time.
rpgParserListener.prototype.enterBif_time = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_time.
rpgParserListener.prototype.exitBif_time = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_timestamp.
rpgParserListener.prototype.enterBif_timestamp = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_timestamp.
rpgParserListener.prototype.exitBif_timestamp = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_tlookup.
rpgParserListener.prototype.enterBif_tlookup = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_tlookup.
rpgParserListener.prototype.exitBif_tlookup = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_tlookuplt.
rpgParserListener.prototype.enterBif_tlookuplt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_tlookuplt.
rpgParserListener.prototype.exitBif_tlookuplt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_tlookuple.
rpgParserListener.prototype.enterBif_tlookuple = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_tlookuple.
rpgParserListener.prototype.exitBif_tlookuple = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_tlookupgt.
rpgParserListener.prototype.enterBif_tlookupgt = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_tlookupgt.
rpgParserListener.prototype.exitBif_tlookupgt = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_tlookupge.
rpgParserListener.prototype.enterBif_tlookupge = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_tlookupge.
rpgParserListener.prototype.exitBif_tlookupge = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_trim.
rpgParserListener.prototype.enterBif_trim = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_trim.
rpgParserListener.prototype.exitBif_trim = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_triml.
rpgParserListener.prototype.enterBif_triml = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_triml.
rpgParserListener.prototype.exitBif_triml = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_trimr.
rpgParserListener.prototype.enterBif_trimr = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_trimr.
rpgParserListener.prototype.exitBif_trimr = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_ucs2.
rpgParserListener.prototype.enterBif_ucs2 = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_ucs2.
rpgParserListener.prototype.exitBif_ucs2 = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_uns.
rpgParserListener.prototype.enterBif_uns = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_uns.
rpgParserListener.prototype.exitBif_uns = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_unsh.
rpgParserListener.prototype.enterBif_unsh = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_unsh.
rpgParserListener.prototype.exitBif_unsh = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_xfoot.
rpgParserListener.prototype.enterBif_xfoot = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_xfoot.
rpgParserListener.prototype.exitBif_xfoot = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_xlate.
rpgParserListener.prototype.enterBif_xlate = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_xlate.
rpgParserListener.prototype.exitBif_xlate = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_xml.
rpgParserListener.prototype.enterBif_xml = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_xml.
rpgParserListener.prototype.exitBif_xml = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_years.
rpgParserListener.prototype.enterBif_years = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_years.
rpgParserListener.prototype.exitBif_years = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_charformat.
rpgParserListener.prototype.enterBif_charformat = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_charformat.
rpgParserListener.prototype.exitBif_charformat = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_dateformat.
rpgParserListener.prototype.enterBif_dateformat = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_dateformat.
rpgParserListener.prototype.exitBif_dateformat = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_timeformat.
rpgParserListener.prototype.enterBif_timeformat = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_timeformat.
rpgParserListener.prototype.exitBif_timeformat = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_editccurrency.
rpgParserListener.prototype.enterBif_editccurrency = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_editccurrency.
rpgParserListener.prototype.exitBif_editccurrency = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_lookupargs.
rpgParserListener.prototype.enterBif_lookupargs = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_lookupargs.
rpgParserListener.prototype.exitBif_lookupargs = function(ctx) {
};


// Enter a parse tree produced by rpgParser#durationCode.
rpgParserListener.prototype.enterDurationCode = function(ctx) {
};

// Exit a parse tree produced by rpgParser#durationCode.
rpgParserListener.prototype.exitDurationCode = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_timestampargs.
rpgParserListener.prototype.enterBif_timestampargs = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_timestampargs.
rpgParserListener.prototype.exitBif_timestampargs = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_tlookupargs.
rpgParserListener.prototype.enterBif_tlookupargs = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_tlookupargs.
rpgParserListener.prototype.exitBif_tlookupargs = function(ctx) {
};


// Enter a parse tree produced by rpgParser#bif_user.
rpgParserListener.prototype.enterBif_user = function(ctx) {
};

// Exit a parse tree produced by rpgParser#bif_user.
rpgParserListener.prototype.exitBif_user = function(ctx) {
};


// Enter a parse tree produced by rpgParser#symbolicConstants.
rpgParserListener.prototype.enterSymbolicConstants = function(ctx) {
};

// Exit a parse tree produced by rpgParser#symbolicConstants.
rpgParserListener.prototype.exitSymbolicConstants = function(ctx) {
};



exports.rpgParserListener = rpgParserListener;