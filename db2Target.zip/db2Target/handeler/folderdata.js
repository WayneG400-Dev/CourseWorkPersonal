const fs = require('fs-extra')

const folderData = (folder) => {
  return new Promise((resolve, reject) => {
    fs.pathExists(folder)
      .then((exists) => {
        if (exists === false) {
          reject(new Error('Unable to find folder.'))
        }
        fs.readdir(folder, function (err, filenames) {
          if (err) {
            reject(new Error(err))
          } else if (filenames.length === 0) {
            reject(new Error('Folder is Empty.'))
          } else if (filenames[0] !== ' ') {
            const filterFiles = filenames.filter(filename => filename.slice(0, 1) !== '.')
            const fullpath = filterFiles.map(x => folder + x)
            resolve(fullpath)
          }
        })
      })
  })
}
module.exports.folderData = folderData
