const folderData = require('./folderdata')
const readFiles = require('./readfiles')

const folderFileData = (path) => {
  return new Promise((resolve, reject) => {
    folderData.folderData(path)
      .then((filenames) => {
        const filterFiles = filenames.filter(filename => filename.slice(0, 1) !== '.')
        return readFiles.readFiles(filterFiles)
      }).then((contents) => {
        resolve(contents)
      }).catch((errorMessage) => {
        reject(new Error(errorMessage))
      })
  })
}

module.exports.folderFileData = folderFileData
