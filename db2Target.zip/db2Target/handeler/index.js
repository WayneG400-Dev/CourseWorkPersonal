'use strict'
/* Importing packages */
const yargs = require('yargs')
// Application Configs
Object.defineProperty(exports, '__esModule', {
  value: true
})
const _config = require('../config')
const _config2 = _interopRequireDefault(_config)
function _interopRequireDefault (obj) { return obj && obj.__esModule ? obj : { default: obj } }
// USAGE: _config2.default.bodyLimit

// File Handelers:
const folderData = require('./folderdata')
const folderFileData = require('./folderfiledata')
const fileData = require('./filedata')
const readFiles = require('./readfiles')

/* Command formation/validation using yargs */
const argv = yargs
    .usage('Usage: node $0 -f <filename>')
    .option({
      filename: {
        alias: 'f',
        description: '<filename> Input file name. ** File must be placed in the <source_in> folder**',
        requiresArg: true
      }
    })
    .help('help').alias('help', 'h')
    .version(false)
    .argv

const argsCheck = () => {
  return new Promise((resolve, reject) => {
    const argInx = process.argv.indexOf('-f')
    if (argInx === -1 || argInx === 0) {
      if (_config2.default.AUTO_LVL === 1) {
        folderData.folderData(_config2.default.DEFAULT_FOLDER)
        .then((resFiles) => {
          readFiles.readFiles(resFiles)
          .then((res) => {
            resolve(res)
          }).catch((errorMessage) => {
            reject(new Error(errorMessage))
          })
        }).catch((errorMessage) => {
          reject(new Error(errorMessage))
        })
      } else {
        folderFileData.folderFileData(_config2.default.DEFAULT_FOLDER)
        .then((res) => {
          resolve(res)
        }).catch((errorMessage) => {
          reject(new Error(errorMessage))
        })
      }
    } else {
      if (_config2.default.AUTO_LOG) console.log(argv)
      const fileName = process.argv[argInx + 1]
      const fullpath = `${_config2.default.DEFAULT_FOLDER}${fileName}`
      fileData.fileData(fullpath)
      .then((res) => {
        resolve(res)
      }).catch((errorMessage) => {
        reject(new Error(errorMessage))
      })
    }
  })
}

module.exports.argsCheck = argsCheck
