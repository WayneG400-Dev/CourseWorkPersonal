const fileData = require('./filedata')

const readFiles = (filepaths) => {
  return new Promise((resolve, reject) => {
    const itemPromises = filepaths.map(fileData.fileData)
    Promise.all(itemPromises)
      .then((contents) => {
        resolve(contents)
      }).catch((errorMessage) => {
        reject(new Error(errorMessage))
      })
  })
}

module.exports.readFiles = readFiles
