const getData = require('./handeler')
const multiParse = require('./grammer')
const db2 = require('./db/db2MultiInsert')
// Application Configs
Object.defineProperty(exports, '__esModule', {
  value: true
})
var _config = require('./config')
var _config2 = _interopRequireDefault(_config)
function _interopRequireDefault (obj) { return obj && obj.__esModule ? obj : { default: obj } }
// USAGE: _config2.default.bodyLimit

if (_config2.default.AUTO_LOG) {
  console.log('Processing Index.js:')
  var start = Date.now()
  var fileimport = Date.now()
  var TParse = Date.now()
  var db2bulk = Date.now()
  var srcFiles = 0
}

getData.argsCheck()
.then((res) => {
  if (_config2.default.AUTO_LOG) {
    fileimport = Date.now()
    console.log('Processing Data Set:')
    console.log(JSON.stringify(res, undefined, 2))
  }
  multiParse.multiParse(res)
  .then((contents) => {
    if (_config2.default.AUTO_LOG) {
      TParse = Date.now()
      console.log('Parsed Data:')
      console.log(JSON.stringify(contents, undefined, 2))
    }
    db2.db2MultiInsert(contents)
      .then((db2res) => {
        if (_config2.default.AUTO_LOG) {
          db2bulk = Date.now()
          console.log('db2 Results:')
          console.log(JSON.stringify(db2res, undefined, 2))
          console.log(`--STATS--`)
          console.log(`Files: ${srcFiles} `)
          console.log(`Time Total: ${(Date.now() - start)} seconds`)
          console.log(`File Total: ${(fileimport - start)} seconds`)
          console.log(`Parse Total: ${(TParse - fileimport)} seconds`)
          console.log(`db Total: ${(db2bulk - TParse)} seconds`)
        }
      }).catch((errorMessage) => {
        console.error(errorMessage)
      })
  }).catch((errorMessage) => {
    console.error(errorMessage)
  })
}).catch((errorMessage) => {
  console.error(errorMessage)
})
